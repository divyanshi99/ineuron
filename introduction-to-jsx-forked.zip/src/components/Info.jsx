import React from "react";
function Info() {
  return (
    <div className="note">
      <h1> JavaScript and React.JS</h1>
      <p>A basic course to Build a Project in React.js</p>
    </div>
  );
}

export default Info;
